SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS lms;
USE lms;

DROP TABLE IF EXISTS admin;
CREATE TABLE IF NOT EXISTS `admin` (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  email varchar(100) NOT NULL,
  password varchar(300) NOT NULL,
  PRIMARY KEY (id);

INSERT INTO admin (id, `name`, email, `password`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin');

DROP TABLE IF EXISTS department;
CREATE TABLE IF NOT EXISTS department (
  id int NOT NULL AUTO_INCREMENT,
  department varchar(255) NOT NULL,
  description text NOT NULL,
  PRIMARY KEY (id);

INSERT INTO department (id, department, description) VALUES
(3, 'PR Department', ''),
(4, 'Sales Department', ''),
(5, 'HR Department', '');

DROP TABLE IF EXISTS employee;
CREATE TABLE IF NOT EXISTS employee (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  mobile varchar(15) NOT NULL,
  password varchar(20) NOT NULL,
  department_id int NOT NULL,
  address varchar(2000) NOT NULL,
  gender varchar(30) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO employee (id, `name`, email, mobile, `password`, department_id, address, gender) VALUES
(2, 'Hamza Rajput', 'hamza@gmail.com', '123456789', '123', 4, 'Quetta', 'male'),
(4, 'Asma', 'asma@gmail.com', '1234567890', '123', 3, 'Quetta', 'female'),
(5, 'Wali Baloch', 'iscobaloch@gmail.com', '03083702100', '1122', 4, 'Quetta, Balochistan', 'male');

DROP TABLE IF EXISTS `leave`;
CREATE TABLE IF NOT EXISTS `leave` (
  id int NOT NULL AUTO_INCREMENT,
  employee_id int NOT NULL,
  leave_id int NOT NULL,
  leave_from varchar(40) NOT NULL,
  leave_to varchar(40) NOT NULL,
  leave_description text NOT NULL,
  leave_status int NOT NULL,
  PRIMARY KEY (id);

INSERT INTO `leave` (id, employee_id, leave_id, leave_from, leave_to, leave_description, leave_status) VALUES
(1, 4, 3, '10/30/2021', '10/31/2021', 'test', 1),
(2, 4, 3, '10/23/2021', '10/30/2021', 'Hello', 3),
(3, 4, 2, '10/25/2021', '10/30/2021', 'hello hamza', 1);

DROP TABLE IF EXISTS leave_type;
CREATE TABLE IF NOT EXISTS leave_type (
  id int NOT NULL AUTO_INCREMENT,
  leave_type varchar(255) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO leave_type (id, leave_type) VALUES
(2, 'Casual'),
(3, 'Earned'),
(4, 'Sick');

DROP TABLE IF EXISTS status;
CREATE TABLE IF NOT EXISTS `status` (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(30) NOT NULL,
  PRIMARY KEY (id)
) ;

INSERT INTO `status` (id, `name`) VALUES
(1, 'approved'),
(2, 'pending'),
(3, 'rejected');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
