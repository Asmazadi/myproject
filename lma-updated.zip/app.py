from flask import Flask, flash, render_template, request, session, redirect, url_for, current_app
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime


app = Flask(__name__)

db = SQLAlchemy()
app.config["SQLALCHEMY_DATABASE_URI"]="mysql+pymysql://admin:12345678@localhost:3306/leave_management_system"
app.config['SECRET_KEY'] = "your secret key here"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

class Admin(db.Model):
    __tablename__ = "admin"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=True)
    email   = db.Column(db.String(120), nullable=True)
    password   = db.Column(db.String(120), nullable=True)

class Employee(db.Model):
    __tablename__ = "employee"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=True)
    department_id = db.Column(db.String(120), unique=True)
    email   = db.Column(db.String(120), nullable=True)
    address = db.Column(db.String(120), nullable=True)
    mobile = db.Column(db.String(120), nullable=True)
    password   = db.Column(db.String(120), nullable=True)
    gender = db.Column(db.String(120), nullable=True)


class Leave(db.Model):
    __tablename__ = "leave"
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, nullable=False)
    leave_from = db.Column(db.Date, nullable=True)
    leave_id = db.Column(db.Integer, nullable=False)
    leave_to = db.Column(db.Date, nullable=True)
    leave_description = db.Column(db.String(300), nullable=True)
    leave_status = db.Column(db.Integer, nullable=True)

class LeaveType(db.Model):
    __tablename__ = "leave_type"
    id = db.Column(db.Integer, primary_key=True)
    leave_type = db.Column(db.Integer, nullable=True)

class Department(db.Model):
    __tablename__ = "department"
    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(300), nullable=True)
    description= db.Column(db.String(300), nullable=True)

class Status(db.Model):
    __tablename__ = "status"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(300), nullable=True)



@app.route("/signin" , methods=['POST','GET'])
def signin():
    if (session.get('admin') or session.get('admin')):
        return redirect(url_for('home'))
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        account= request.form.get('role').replace(" ","")
        if account=='admin':
            adm = Admin.query.filter_by(email=email, password=password).first()
            if adm:
                session['admin'] = adm.email
                session['name']= adm.name
                return redirect(url_for('home'))
            else:
                return redirect(url_for('signin'))
        else:
            emp= Employee.query.filter_by(email=email, password=password).first()
            if emp:
                session['username'] = emp.email
                session['name'] = emp.name
                session['id'] = emp.id
                return redirect(url_for('home'))
            else:
                return redirect(url_for('signin'))
    else:
        return render_template("login.html")

@app.route("/logout")
def logout():
        session.clear()
        return redirect(url_for('signin'))


# Home Page
@app.route("/")
def home():
    if session.get('admin'):
        req= db.session.query(Employee, Leave, LeaveType).filter(Leave.leave_status==2)\
            .filter(Leave.employee_id==Employee.id).filter(LeaveType.id==Leave.leave_id).order_by(Leave.id.desc()).all()
        return render_template("admin/index.html", requ=req)
    if session.get('username'):
        return render_template("index.html")
    else:
        return redirect(url_for('signin'))

#Admin Section
@app.route("/employees", methods=['POST','GET'])
def employees():
    if session.get('admin'):
        emp= db.session.query(Employee, Department).filter(Employee.department_id==Department.id).all()
        return render_template("admin/employees.html",emp=emp)
    else:
        return redirect(url_for('home'))

@app.route("/new-employee", methods=['POST','GET'])
def add_employees():
    if session.get('admin'):
        dpt=Department.query.all()
        if request.method=='POST':
            name=request.form.get('name')
            email=request.form.get('email')
            dept= request.form.get('department')
            address= request.form.get('address')
            gender=request.form.get('gender')
            phone=request.form.get('phone')
            password=request.form.get('password')
            nr= Employee(name=name,mobile=phone, department_id=dept, email=email, address=address, gender=gender,
                         password=password)
            db.session.add(nr)
            db.session.commit()
            return render_template("admin/add_employee.html",dpt=dpt)
        else:
            return render_template("admin/add_employee.html", dpt=dpt)
    else:
        return redirect(url_for('home'))

@app.route("/delete_employee_<id>", methods=['POST','GET'])
def del_emp(id):
    if session.get('admin'):
        rec= db.session.query(Employee).filter(Employee.id==id).first()
        db.session.delete(rec)
        db.session.commit()
        return redirect(url_for('employees'))
    else:
        return redirect(url_for('home'))



@app.route("/add_type", methods=['POST','GET'])
def add_type():
    if session.get('admin'):
        if request.method=='POST':
            ltype= request.form.get('ltype')
            dep= LeaveType(leave_type=ltype)
            db.session.add(dep)
            db.session.commit()
            return redirect(url_for('leave_types'))
        else:
            return render_template("admin/add_type.html")
    else:
        return redirect(url_for('home'))

@app.route("/new-department", methods=['POST','GET'])
def add_department():
    if session.get('admin'):
        if request.method == 'POST':
            department = request.form.get('dptname')
            description = request.form.get('descript')
            dep = Department(department=department, description=description)
            db.session.add(dep)
            db.session.commit()
            return redirect(url_for('departments'))
        else:
            return render_template("admin/add_department.html")
    else:
        return redirect(url_for('home'))

@app.route("/delete_department_<id>", methods=['POST','GET'])
def del_department(id):
    if session.get('admin'):
        rec= db.session.query(Department).filter(Department.id==id).first()
        db.session.delete(rec)
        db.session.commit()
        return redirect(url_for('departments'))
    else:
        return redirect(url_for('home'))

@app.route("/leave_requests", methods=['POST','GET'])
def leave_log():
    if session.get('admin'):
        lv= db.session.query(Leave,Employee,LeaveType,Status,Department).filter(Leave.employee_id==Employee.id)\
        .filter(Leave.leave_id==LeaveType.id).filter(Employee.department_id==Department.id)\
            .filter(Leave.leave_status==Status.id).order_by(Leave.id.desc()).all()
        return render_template("admin/requests.html",lv=lv)
    else:
        return redirect(url_for('home'))

@app.route("/action/request_id=<id>", methods=['POST','GET'])
def action(id):
    if session.get('admin'):
        req= db.session.query(Leave,Employee,LeaveType,Status,Department).filter(Leave.id==id).filter(Leave.leave_id==LeaveType.id).filter(Leave.employee_id==Employee.id)\
        .filter(Employee.department_id==Department.id)\
            .filter(Leave.leave_status==2).order_by(Leave.id.desc()).first()
        if req:
            if request.method=='POST':
                upd= request.form.get('leave')
                rec= db.session.query(Leave).filter(Leave.id==id).first()
                rec.leave_status=upd
                db.session.commit()
                return redirect(url_for('home'))
            else:
                return render_template("admin/action.html", req=req)
        else:
            return redirect(url_for('home'))
    else:
        return redirect(url_for('home'))

@app.route("/leave_types", methods=['POST','GET'])
def leave_types():
    if session.get('admin'):
        lv= db.session.query(LeaveType).all()
        return render_template("admin/leave_types.html",lv=lv)
    else:
        return redirect(url_for('home'))

@app.route("/delete_leave_type_<id>", methods=['POST','GET'])
def del_ltype(id):
    if session.get('admin'):
        rec= db.session.query(LeaveType).filter(LeaveType.id==id).first()
        db.session.delete(rec)
        db.session.commit()
        return redirect(url_for('leave_types'))
    else:
        return redirect(url_for('home'))

@app.route("/departments", methods=['POST','GET'])
def departments():
    if session.get('admin'):
        dep= db.session.query(Department).all()
        return render_template("admin/department.html",dep=dep)
    else:
        return redirect(url_for('home'))

# Employee Section
@app.route("/leave", methods=['POST','GET'])
def leave():
    if session.get('username'):
        if request.method=='POST':
            ltype= request.form.get('leave_type')
            lfrom = request.form.get('lfrom')
            lto = request.form.get('lto')
            description = request.form.get('description')
            new= Leave(employee_id=session.get('id'),leave_id=ltype,leave_from=lfrom,leave_to=lto,
                       leave_description=description, leave_status=2)
            db.session.add(new)
            db.session.commit()
            flash('Leave Request Submitted')
            return render_template("leave.html")
        else:
            typ= LeaveType.query.all()
            return render_template("leave.html",typ=typ)
    else:
        return redirect(url_for('home'))

@app.route("/leave-history", methods=['POST','GET'])
def leave_history():
    if session.get('username'):
        res= db.session.query(Employee, Leave, LeaveType, Status).filter(Employee.id==session.get('id'))\
            .filter(Leave.employee_id==Employee.id).filter(Leave.leave_id==LeaveType.id)\
            .filter(Leave.leave_status==Status.id).order_by(Leave.id.desc()).all()
        return render_template("leave_history.html", res=res)
    else:
        return redirect(url_for('home'))

if __name__ == "__main__":

    app.run(debug=True)
